/**
 * Team represents a row in the CSV File, comprised of it's 29 variables
 * @author Jordan Mabalatan
 *
 */

public class Team {

    private String schoolName; //name of the schools' basketball team
    private String shortName; //short version of schoolName
    private String region; //region for the tournament
    private int seedNumber; //seed for the tournament
    private double winRating; //win rating for team based on W/L record and strength of schedule
    private double gamesPlayed; //number of games played
    private double wins; //number of games won
    private double losses; //number of games lost
    private double winLossPercentage; //number of wins divided by gamesPlayed
    private double strengthOfSchedule; //Strength of Schedule (SOS); a rating of strength of schedule. The rating is denominated in points above/below average, where zero is average. Non-Division I games are excluded from the ratings.
    private double minutesPlayed; //number of minutes played
    private double fieldGoals; //number of field goals made
    private double fieldGoalsAttempted; //number of field goals attempted
    private double fieldGoalPercentage; //number of fieldGoals divided by fieldGoalsAttempted
    private double threePointers; //number of three pointers made
    private double threePointersAttempted; //number of three pointers attempted 
    private double threePointerPercentage; //number of threePointers divided by threePointersAttempted
    private double freeThrows; //number of free throws made
    private double freeThrowsAttempted; //number of free throws attempted
    private double freeThrowPercentage; //number of freeThrows divided by freeThrowsAttempted
    private double offensiveRebounds; //number of rebounds while playing offense
    private double defensiveRebounds; //number of rebounds while playing defense
    private double totalRebounds; //sum of offensiveRebounds plus defensiveRebounds
    private double assists; //number of assists
    private double steals; //number of steals
    private double blocks; //number of blocks
    private double turnovers; //number of turnovers
    private double personalFouls; //number of personal fouls
    
    /**
     * 
     * @param currSchool
     * @param currShort
     * @param currRegion
     * @param tourneySeed
     * @param seasonWinRating
     * @param seasonGP
     * @param seasonWs
     * @param seasonLs
     * @param seasonWLP
     * @param seasonSRS
     * @param seasonSOS
     * @param seasonMP
     * @param seasonFGM
     * @param seasonFGA
     * @param seasonFGP
     * @param season3PM
     * @param season3PA
     * @param season3PP
     * @param seasonFTM
     * @param seasonFTA
     * @param seasonFTP
     * @param seasonORB
     * @param seasonDRB
     * @param seasonTRB
     * @param seasonAST
     * @param seasonSTL
     * @param seasonBLK
     * @param seasonTOV
     * @param seasonPF
     */
    
    public Team (String currSchool, String currShort, String currRegion, int tourneySeed, double seasonWinRating, double seasonGP, double seasonWs, double seasonLs, double seasonWLP, 
    		double seasonSOS, double seasonMP, double seasonFGM, double seasonFGA, double seasonFGP, 
            double season3PM, double season3PA, double season3PP, double seasonFTM, double seasonFTA, double seasonFTP, 
            double seasonORB, double seasonDRB, double seasonTRB, double seasonAST, double seasonSTL, double seasonBLK, 
            double seasonTOV, double seasonPF) {
        
        schoolName = currSchool;
        shortName = currShort;
        region = currRegion;
        seedNumber = tourneySeed;
        winRating = seasonWinRating;
        gamesPlayed = seasonGP;
        wins = seasonWs;
        losses = seasonLs;
        winLossPercentage = seasonWLP;
        strengthOfSchedule = seasonSOS;
        minutesPlayed = seasonMP;
        fieldGoals = seasonFGM;
        fieldGoalsAttempted = seasonFGA;
        fieldGoalPercentage = seasonFGP;
        threePointers = season3PM;
        threePointersAttempted = season3PA;
        threePointerPercentage = season3PP;
        freeThrows = seasonFTM;
        freeThrowsAttempted = seasonFTA;
        freeThrowPercentage = seasonFTP;
        offensiveRebounds = seasonORB;
        defensiveRebounds = seasonDRB;
        totalRebounds = seasonTRB;
        assists = seasonAST;
        steals = seasonSTL;
        blocks = seasonBLK;
        turnovers = seasonTOV;
        personalFouls = seasonPF;
        
    }

    /**
     * getter methods for each of the instance variables in the Team class
     * @return
     */
    
    public String getSchoolName() {
        return schoolName;
    }


    public String getShortName() {
        return shortName;
    }
    
    public String getRegion() {
        return region;
    }


    public int getSeedNumber() {
        return seedNumber;
    }
    
    public double getWinRating() {
        return winRating;
    }


    public double getGamesPlayed() {
        return gamesPlayed;
    }


    public double getWins() {
        return wins;
    }


    public double getLosses() {
        return losses;
    }


    public double getWinLossPercentage() {
        return winLossPercentage;
    }


    public double getStrengthOfSchedule() {
        return strengthOfSchedule;
    }


    public double getMinutesPlayed() {
        return minutesPlayed;
    }


    public double getFieldGoals() {
        return fieldGoals;
    }


    public double getFieldGoalsAttempted() {
        return fieldGoalsAttempted;
    }


    public double getFieldGoalPercentage() {
        return fieldGoalPercentage;
    }


    public double getThreePointers() {
        return threePointers;
    }


    public double getThreePointersAttempted() {
        return threePointersAttempted;
    }


    public double getThreePointerPercentage() {
        return threePointerPercentage;
    }


    public double getFreeThrows() {
        return freeThrows;
    }


    public double getFreeThrowsAttempted() {
        return freeThrowsAttempted;
    }


    public double getFreeThrowPercentage() {
        return freeThrowPercentage;
    }


    public double getOffensiveRebounds() {
        return offensiveRebounds;
    }


    public double getDefensiveRebounds() {
        return defensiveRebounds;
    }


    public double getTotalRebounds() {
        return totalRebounds;
    }


    public double getAssists() {
        return assists;
    }


    public double getSteals() {
        return steals;
    }


    public double getBlocks() {
        return blocks;
    }


    public double getTurnovers() {
        return turnovers;
    }


    public double getPersonalFouls() {
        return personalFouls;
    }
    
}