# final-project-team-60
final-project-team-60 created by GitHub Classroom

March Madness Bracket Builder 2020 is a program that allows users to simulate the NCAA Division I Men's Basketball Tournament (also known as March Madness).

The NCAA Division I Men's Basketball Tournament is a single-elimination tournament played to determine a National Champion.
A bracket is initialized for the user to simulate matchups from a field of 64 teams.  After a matchup is simulated, the winner
proceeds to the next round as the field narrows down from 64, 32, 16, 8, 4, 2 and the ultimately, the last team standing is 
crowned the National Champion.

Users will be able to click on a team's name to get a summary of statistically relevant information to help guide simulations.
Users will then be able to simulate a matchup based on Win Rating (a created metric made up of W/L record, strength of schedule,
and statistical differentials), Historical Probabilities, Historical Probabilities + FG%, Historical Probabilities + 3PT%, and Historical 
Probabilities + FT%.

Both teams from a prior round will need to be determined before simulating a matchup, if the user tries to simulate a matchup too 
far ahead, they will be prompted by a message to complete all preceding matchups before continuing.  After the final matchup is 
simulated, the winner of the tournament has been determined!
