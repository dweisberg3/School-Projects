import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JTable;
import javax.swing.JSpinner;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.JScrollPane;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JList;


import javax.swing.JToggleButton;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;

import java.awt.Font;
import java.awt.Color;

/**
 * Our program will utilize a J-Swing GUI, built using Java's WindowBuilder plug-in.  The GUI consists of a frame, buttons for each part of the
 * tournament bracket, and J-separators for delineating the path between match-ups in the bracket
 * @author mpcot
 *
 */
public class BracketGUI {
	
	static BracketTracker bracket = new BracketTracker();
	
	private JFrame frame;
	private JTextField txtMarchMadnessBracket;
	private JTextField txtBracketBuilder;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		TeamDataReader.readCSV();
		bracket.initializeBracketTracker();
				
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BracketGUI window = new BracketGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public BracketGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		MatchupSimulator myMS = new MatchupSimulator();
		frame = new JFrame();
		frame.setBounds(100, 100, 1231, 664);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		/**
		 * Our bracket will consist of JButtons, with the first columns of buttons (i.e. round 1, 32 buttons in far left column and 32 buttons in far right column)
		 * including one button for each team, which allow the user to click the button and return a dialog box that displays that team's key stats for
		 * the 2020 season.  Subsequent buttons (i.e. all columns other than the far left and far right) will consist of drop down menus, where the user
		 * can select his/her desired method for determining the winner of that match-up.  Once the user selects the desired method for determining a
		 * winner for a given match-up, the button will populate the winning team's name.  
		 */
		
		ArrayList<JButton> roundOneLeftSideJButtons = getJButtonOpeningRoundData(32, 0);
		
		roundOneLeftSideJButtons.get(0).setBounds(1, 0, 80, 15);
		roundOneLeftSideJButtons.get(1).setBounds(1, 15, 80, 15);
		roundOneLeftSideJButtons.get(2).setBounds(1, 35, 80, 15);
		roundOneLeftSideJButtons.get(3).setBounds(1, 50, 80, 15);
		roundOneLeftSideJButtons.get(4).setBounds(1, 70, 80, 15);
		roundOneLeftSideJButtons.get(5).setBounds(1, 85, 80, 15);
		roundOneLeftSideJButtons.get(6).setBounds(1, 105, 80, 15);
		roundOneLeftSideJButtons.get(7).setBounds(1, 120, 80, 15);
		roundOneLeftSideJButtons.get(8).setBounds(1, 140, 80, 15);
		roundOneLeftSideJButtons.get(9).setBounds(1, 155, 80, 15);
		roundOneLeftSideJButtons.get(10).setBounds(1, 175, 80, 15);
		roundOneLeftSideJButtons.get(11).setBounds(1, 190, 80, 15);
		roundOneLeftSideJButtons.get(12).setBounds(1, 210, 80, 15);
		roundOneLeftSideJButtons.get(13).setBounds(1, 225, 80, 15);
		roundOneLeftSideJButtons.get(14).setBounds(1, 245, 80, 15);
		roundOneLeftSideJButtons.get(15).setBounds(1, 260, 80, 15);
		roundOneLeftSideJButtons.get(16).setBounds(1, 343, 80, 15);
		roundOneLeftSideJButtons.get(17).setBounds(1, 358, 80, 15);
		roundOneLeftSideJButtons.get(17).setFont(new Font("Tahoma", Font.PLAIN, 8));
		roundOneLeftSideJButtons.get(18).setBounds(1, 378, 80, 15);
		roundOneLeftSideJButtons.get(19).setBounds(1, 393, 80, 15);
		roundOneLeftSideJButtons.get(20).setBounds(1, 413, 80, 15);
		roundOneLeftSideJButtons.get(21).setBounds(1, 428, 80, 15);
		roundOneLeftSideJButtons.get(22).setBounds(1, 448, 80, 15);
		roundOneLeftSideJButtons.get(23).setBounds(1, 463, 80, 15);
		roundOneLeftSideJButtons.get(24).setBounds(1, 483, 80, 15);
		roundOneLeftSideJButtons.get(25).setBounds(1, 498, 80, 15);
		roundOneLeftSideJButtons.get(26).setBounds(1, 518, 80, 15);
		roundOneLeftSideJButtons.get(27).setBounds(1, 533, 80, 15);
		roundOneLeftSideJButtons.get(28).setBounds(1, 553, 80, 15);
		roundOneLeftSideJButtons.get(29).setBounds(1, 568, 80, 15);
		roundOneLeftSideJButtons.get(30).setBounds(1, 588, 80, 15);
		roundOneLeftSideJButtons.get(31).setBounds(1, 603, 80, 15);
		
		for(int x = 0; x < roundOneLeftSideJButtons.size(); x++) {
			frame.getContentPane().add(roundOneLeftSideJButtons.get(x));
		}
		

		/**
		 * Example button location where button will consist of a drop down menu for selecting method for determining winner of match-up.
		 * This button functionality is repeated for all remaining buttons in the bracket.
		 */
		
		ArrayList<JButton> roundTwoLeftSideJButtons = new ArrayList<>();
		for(int x = 0; x < 16; x++) {
			
			JButton button = new JButton("");
			button.setFont(new Font("Tahoma", Font.PLAIN, 9));
			
			 int j = x;
			button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null; 
		    
		           	if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[j * 2][0], bracket.bracket[j * 2 + 1][0]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[j * 2][0], bracket.bracket[j * 2 + 1][0]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[j * 2][0], bracket.bracket[j * 2 + 1][0]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[j * 2][0], bracket.bracket[j * 2 + 1][0]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[j * 2][0], bracket.bracket[j * 2 + 1][0]);
		            }
		            bracket.bracket[j][1] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
			}
		});
			roundTwoLeftSideJButtons.add(button);
		};
		
		roundTwoLeftSideJButtons.get(0).setBounds(90, 7, 80, 15);
		roundTwoLeftSideJButtons.get(1).setBounds(91, 42, 80, 15);
		roundTwoLeftSideJButtons.get(2).setBounds(91, 77, 80, 15);
		roundTwoLeftSideJButtons.get(3).setBounds(91, 112, 80, 15);
		roundTwoLeftSideJButtons.get(4).setBounds(91, 147, 80, 15);
		roundTwoLeftSideJButtons.get(5).setBounds(91, 182, 80, 15);
		roundTwoLeftSideJButtons.get(6).setBounds(91, 217, 80, 15);
		roundTwoLeftSideJButtons.get(7).setBounds(90, 252, 80, 15);
		roundTwoLeftSideJButtons.get(8).setBounds(90, 350, 80, 15);
		roundTwoLeftSideJButtons.get(9).setBounds(90, 385, 80, 15);
		roundTwoLeftSideJButtons.get(10).setBounds(91, 420, 80, 15);
		roundTwoLeftSideJButtons.get(11).setBounds(91, 455, 80, 15);
		roundTwoLeftSideJButtons.get(12).setBounds(91, 490, 80, 15);
		roundTwoLeftSideJButtons.get(13).setBounds(91, 525, 80, 15);
		roundTwoLeftSideJButtons.get(14).setBounds(91, 560, 80, 15);
		roundTwoLeftSideJButtons.get(15).setBounds(90, 595, 80, 15);
		for(int x = 0; x < 16; x++) {
			frame.getContentPane().add(roundTwoLeftSideJButtons.get(x));
		}
	
		
		JSeparator separator = new JSeparator();
		separator.setBounds(80, 259, 20, 1);
		frame.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(80, 224, 20, 1);
		frame.getContentPane().add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(80, 189, 20, 1);
		frame.getContentPane().add(separator_2);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(80, 154, 20, 1);
		frame.getContentPane().add(separator_3);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setBounds(80, 119, 20, 1);
		frame.getContentPane().add(separator_4);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setBounds(80, 84, 20, 1);
		frame.getContentPane().add(separator_5);
		
		JSeparator separator_6 = new JSeparator();
		separator_6.setBounds(80, 49, 20, 1);
		frame.getContentPane().add(separator_6);
		
		JSeparator separator_7 = new JSeparator();
		separator_7.setBounds(80, 14, 20, 1);
		frame.getContentPane().add(separator_7);
		
		ArrayList<JButton> roundThreeLeftSideJButtons = new ArrayList<>();
		for(int x = 0; x < 8; x++) {
			
			JButton button = new JButton("");
			button.setFont(new Font("Tahoma", Font.PLAIN, 9));
			
			final int j = x;
			button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (bracket.bracket[j * 2][1] == null || bracket.bracket[j * 2 + 1][1] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null; 
		    
		           	if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[j * 2][1], bracket.bracket[j * 2 + 1][1]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[j * 2][1], bracket.bracket[j * 2 + 1][1]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[j * 2][1], bracket.bracket[j * 2 + 1][1]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[j * 2][1], bracket.bracket[j * 2 + 1][1]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[j * 2][1], bracket.bracket[j * 2 + 1][1]);
		            }
		            bracket.bracket[j][2] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button.setText("(" + winnerSeed + ")" + " " + winnerName);
				}    
			}
		});
			roundThreeLeftSideJButtons.add(button);
		};
		
		roundThreeLeftSideJButtons.get(0).setBounds(194, 24, 80, 15);
		roundThreeLeftSideJButtons.get(1).setBounds(194, 93, 80, 15);
		roundThreeLeftSideJButtons.get(2).setBounds(194, 163, 80, 15);
		roundThreeLeftSideJButtons.get(3).setBounds(194, 233, 80, 15);
		roundThreeLeftSideJButtons.get(4).setBounds(194, 367, 80, 15);
		roundThreeLeftSideJButtons.get(5).setBounds(194, 436, 80, 15);
		roundThreeLeftSideJButtons.get(6).setBounds(194, 506, 80, 15);
		roundThreeLeftSideJButtons.get(7).setBounds(194, 576, 80, 15);

		
		for(int x = 0; x < 8; x++) {
			frame.getContentPane().add(roundThreeLeftSideJButtons.get(x));
		};
		

		JSeparator separator_8 = new JSeparator();
		separator_8.setBounds(168, 13, 12, 1);
		frame.getContentPane().add(separator_8);
		
		JSeparator separator_10 = new JSeparator();
		separator_10.setOrientation(SwingConstants.VERTICAL);
		separator_10.setBounds(179, 13, 2, 37);
		frame.getContentPane().add(separator_10);
		
		JSeparator separator_9 = new JSeparator();
		separator_9.setBounds(168, 50, 12, 1);
		frame.getContentPane().add(separator_9);
		
		JSeparator separator_11 = new JSeparator();
		separator_11.setBounds(179, 31, 15, 1);
		frame.getContentPane().add(separator_11);
		
		JSeparator separator_12 = new JSeparator();
		separator_12.setBounds(179, 100, 15, 1);
		frame.getContentPane().add(separator_12);
		
	
		
		JSeparator separator_13 = new JSeparator();
		separator_13.setOrientation(SwingConstants.VERTICAL);
		separator_13.setBounds(179, 82, 2, 37);
		frame.getContentPane().add(separator_13);
		
		JSeparator separator_14 = new JSeparator();
		separator_14.setBounds(168, 119, 12, 1);
		frame.getContentPane().add(separator_14);
		
		JSeparator separator_15 = new JSeparator();
		separator_15.setBounds(168, 82, 12, 1);
		frame.getContentPane().add(separator_15);
		
		JSeparator separator_16 = new JSeparator();
		separator_16.setBounds(179, 170, 15, 1);
		frame.getContentPane().add(separator_16);
		

		
		JSeparator separator_17 = new JSeparator();
		separator_17.setOrientation(SwingConstants.VERTICAL);
		separator_17.setBounds(179, 152, 5, 37);
		frame.getContentPane().add(separator_17);
		
		JSeparator separator_18 = new JSeparator();
		separator_18.setBounds(168, 189, 12, 1);
		frame.getContentPane().add(separator_18);
		
		JSeparator separator_19 = new JSeparator();
		separator_19.setBounds(168, 152, 12, 1);
		frame.getContentPane().add(separator_19);
		
		JSeparator separator_20 = new JSeparator();
		separator_20.setBounds(179, 240, 15, 1);
		frame.getContentPane().add(separator_20);
		

		
		JSeparator separator_21 = new JSeparator();
		separator_21.setOrientation(SwingConstants.VERTICAL);
		separator_21.setBounds(179, 222, 5, 37);
		frame.getContentPane().add(separator_21);
		
		JSeparator separator_22 = new JSeparator();
		separator_22.setBounds(168, 259, 12, 1);
		frame.getContentPane().add(separator_22);
		
		JSeparator separator_23 = new JSeparator();
		separator_23.setBounds(168, 222, 12, 1);
		frame.getContentPane().add(separator_23);
		
		JSeparator separator_24 = new JSeparator();
		separator_24.setBounds(274, 31, 15, 1);
		frame.getContentPane().add(separator_24);
		
		JSeparator separator_25 = new JSeparator();
		separator_25.setBounds(274, 100, 15, 1);
		frame.getContentPane().add(separator_25);
		
		JSeparator separator_26 = new JSeparator();
		separator_26.setBounds(274, 170, 15, 1);
		frame.getContentPane().add(separator_26);
		
		JSeparator separator_27 = new JSeparator();
		separator_27.setBounds(274, 240, 15, 1);
		frame.getContentPane().add(separator_27);
		
		JSeparator separator_28 = new JSeparator();
		separator_28.setBounds(289, 65, 15, 1);
		frame.getContentPane().add(separator_28);
		
		ArrayList<JButton> roundFourLeftSideJButtons = new ArrayList<>();
		for(int x = 0; x < 4; x++) {
			
			JButton button = new JButton("");
			button.setFont(new Font("Tahoma", Font.PLAIN, 9));
			
			final int j = x;
			button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (bracket.bracket[j * 2][2] == null || bracket.bracket[j * 2 + 1][2] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null; 
		    
		           	if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[j * 2][2], bracket.bracket[j * 2 + 1][2]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[j * 2][2], bracket.bracket[j * 2 + 1][2]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[j * 2][2], bracket.bracket[j * 2 + 1][2]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[j * 2][2], bracket.bracket[j * 2 + 1][2]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[j * 2][2], bracket.bracket[j * 2 + 1][2]);
		            }
		            bracket.bracket[j][3] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button.setText("(" + winnerSeed + ")" + " " + winnerName);
				}    
			}
		});
			roundFourLeftSideJButtons.add(button);
		};
		
		roundFourLeftSideJButtons.get(0).setBounds(304, 59, 80, 15);
		roundFourLeftSideJButtons.get(1).setBounds(304, 198, 80, 15);
		roundFourLeftSideJButtons.get(2).setBounds(304, 402, 80, 15);
		roundFourLeftSideJButtons.get(3).setBounds(304, 541, 80, 15);
		

		
		for(int x = 0; x < 4; x++) {
			frame.getContentPane().add(roundFourLeftSideJButtons.get(x));
		};
		
	
		
		
		JSeparator separator_29 = new JSeparator();
		separator_29.setBounds(384, 65, 15, 1);
		frame.getContentPane().add(separator_29);
		
		JSeparator separator_30 = new JSeparator();
		separator_30.setOrientation(SwingConstants.VERTICAL);
		separator_30.setBounds(288, 31, 1, 69);
		frame.getContentPane().add(separator_30);
		
		JSeparator separator_31 = new JSeparator();
		separator_31.setBounds(289, 205, 15, 1);
		frame.getContentPane().add(separator_31);
		
	
		
		JSeparator separator_32 = new JSeparator();
		separator_32.setBounds(384, 205, 15, 1);
		frame.getContentPane().add(separator_32);
		
		JSeparator separator_33 = new JSeparator();
		separator_33.setOrientation(SwingConstants.VERTICAL);
		separator_33.setBounds(288, 171, 1, 69);
		frame.getContentPane().add(separator_33);
		
		JSeparator separator_34 = new JSeparator();
		separator_34.setOrientation(SwingConstants.VERTICAL);
		separator_34.setBounds(398, 65, 1, 140);
		frame.getContentPane().add(separator_34);
		
		JSeparator separator_35 = new JSeparator();
		separator_35.setBounds(398, 135, 15, 2);
		frame.getContentPane().add(separator_35);
		
		JButton button_46 = new JButton("");
		button_46.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_46.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bracket.bracket[0][3] == null || bracket.bracket[1][3] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null;
		           	int x = 0;
		           	int y = 3;
		           	int a = 1;
		           	int b = 3;
		            if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            bracket.bracket[0][4] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button_46.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
				}
			}
		});
		button_46.setBounds(413, 129, 80, 15);
		frame.getContentPane().add(button_46);

			
		
		
	
		
		JSeparator separator_36 = new JSeparator();
		separator_36.setBounds(80, 602, 20, 1);
		frame.getContentPane().add(separator_36);
		
		JSeparator separator_37 = new JSeparator();
		separator_37.setBounds(80, 567, 20, 1);
		frame.getContentPane().add(separator_37);
		
		JSeparator separator_38 = new JSeparator();
		separator_38.setBounds(80, 532, 20, 1);
		frame.getContentPane().add(separator_38);
		
		JSeparator separator_39 = new JSeparator();
		separator_39.setBounds(80, 497, 20, 1);
		frame.getContentPane().add(separator_39);
		
		JSeparator separator_40 = new JSeparator();
		separator_40.setBounds(80, 462, 20, 1);
		frame.getContentPane().add(separator_40);
		
		JSeparator separator_41 = new JSeparator();
		separator_41.setBounds(80, 427, 20, 1);
		frame.getContentPane().add(separator_41);
		
		JSeparator separator_42 = new JSeparator();
		separator_42.setBounds(80, 392, 20, 1);
		frame.getContentPane().add(separator_42);
		
		JSeparator separator_43 = new JSeparator();
		separator_43.setBounds(80, 357, 20, 1);
		frame.getContentPane().add(separator_43);
		

		
		JSeparator separator_44 = new JSeparator();
		separator_44.setBounds(168, 356, 12, 1);
		frame.getContentPane().add(separator_44);
		
		JSeparator separator_45 = new JSeparator();
		separator_45.setOrientation(SwingConstants.VERTICAL);
		separator_45.setBounds(179, 356, 2, 37);
		frame.getContentPane().add(separator_45);
		
		JSeparator separator_46 = new JSeparator();
		separator_46.setBounds(168, 393, 12, 1);
		frame.getContentPane().add(separator_46);
		
		JSeparator separator_47 = new JSeparator();
		separator_47.setBounds(179, 374, 15, 1);
		frame.getContentPane().add(separator_47);
		
		JSeparator separator_48 = new JSeparator();
		separator_48.setBounds(179, 443, 15, 1);
		frame.getContentPane().add(separator_48);
		

		
		JSeparator separator_49 = new JSeparator();
		separator_49.setOrientation(SwingConstants.VERTICAL);
		separator_49.setBounds(179, 425, 2, 37);
		frame.getContentPane().add(separator_49);
		
		JSeparator separator_50 = new JSeparator();
		separator_50.setBounds(168, 462, 12, 1);
		frame.getContentPane().add(separator_50);
		
		JSeparator separator_51 = new JSeparator();
		separator_51.setBounds(168, 425, 12, 1);
		frame.getContentPane().add(separator_51);
		
		JSeparator separator_52 = new JSeparator();
		separator_52.setBounds(179, 513, 15, 1);
		frame.getContentPane().add(separator_52);
		
	
		
		JSeparator separator_53 = new JSeparator();
		separator_53.setOrientation(SwingConstants.VERTICAL);
		separator_53.setBounds(179, 495, 5, 37);
		frame.getContentPane().add(separator_53);
		
		JSeparator separator_54 = new JSeparator();
		separator_54.setBounds(168, 532, 12, 1);
		frame.getContentPane().add(separator_54);
		
		JSeparator separator_55 = new JSeparator();
		separator_55.setBounds(168, 495, 12, 1);
		frame.getContentPane().add(separator_55);
		
		JSeparator separator_56 = new JSeparator();
		separator_56.setBounds(179, 583, 15, 1);
		frame.getContentPane().add(separator_56);
		

		
		JSeparator separator_57 = new JSeparator();
		separator_57.setOrientation(SwingConstants.VERTICAL);
		separator_57.setBounds(179, 565, 5, 37);
		frame.getContentPane().add(separator_57);
		
		JSeparator separator_58 = new JSeparator();
		separator_58.setBounds(168, 602, 12, 1);
		frame.getContentPane().add(separator_58);
		
		JSeparator separator_59 = new JSeparator();
		separator_59.setBounds(168, 565, 12, 1);
		frame.getContentPane().add(separator_59);
		
		JSeparator separator_60 = new JSeparator();
		separator_60.setBounds(274, 374, 15, 1);
		frame.getContentPane().add(separator_60);
		
		JSeparator separator_61 = new JSeparator();
		separator_61.setBounds(274, 443, 15, 1);
		frame.getContentPane().add(separator_61);
		
		JSeparator separator_62 = new JSeparator();
		separator_62.setBounds(274, 513, 15, 1);
		frame.getContentPane().add(separator_62);
		
		JSeparator separator_63 = new JSeparator();
		separator_63.setBounds(274, 583, 15, 1);
		frame.getContentPane().add(separator_63);
		
		JSeparator separator_64 = new JSeparator();
		separator_64.setBounds(289, 408, 15, 1);
		frame.getContentPane().add(separator_64);
		
		
		
		JSeparator separator_65 = new JSeparator();
		separator_65.setBounds(384, 408, 15, 1);
		frame.getContentPane().add(separator_65);
		
		JSeparator separator_66 = new JSeparator();
		separator_66.setOrientation(SwingConstants.VERTICAL);
		separator_66.setBounds(288, 374, 1, 69);
		frame.getContentPane().add(separator_66);
		
		JSeparator separator_67 = new JSeparator();
		separator_67.setBounds(289, 548, 15, 1);
		frame.getContentPane().add(separator_67);
		

		
		JSeparator separator_68 = new JSeparator();
		separator_68.setBounds(384, 548, 15, 1);
		frame.getContentPane().add(separator_68);
		
		JSeparator separator_69 = new JSeparator();
		separator_69.setOrientation(SwingConstants.VERTICAL);
		separator_69.setBounds(288, 514, 1, 69);
		frame.getContentPane().add(separator_69);
		
		JSeparator separator_70 = new JSeparator();
		separator_70.setOrientation(SwingConstants.VERTICAL);
		separator_70.setBounds(398, 408, 1, 140);
		frame.getContentPane().add(separator_70);
		
		JSeparator separator_71 = new JSeparator();
		separator_71.setBounds(398, 478, 15, 2);
		frame.getContentPane().add(separator_71);
		
		JButton button_77 = new JButton("");
		button_77.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_77.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bracket.bracket[2][3] == null || bracket.bracket[3][3] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null;
		           	int x = 2;
		           	int y = 3;
		           	int a = 3;
		           	int b = 3;
		            if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            bracket.bracket[1][4] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button_77.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
				}
			}
		});
		button_77.setBounds(413, 472, 80, 15);
		frame.getContentPane().add(button_77);
		
		JSeparator separator_72 = new JSeparator();
		separator_72.setBounds(1123, 14, 9, 1);
		frame.getContentPane().add(separator_72);
		
		JSeparator separator_73 = new JSeparator();
		separator_73.setBounds(1123, 49, 9, 1);
		frame.getContentPane().add(separator_73);
		
		JSeparator separator_74 = new JSeparator();
		separator_74.setBounds(1123, 84, 9, 1);
		frame.getContentPane().add(separator_74);
		
		JSeparator separator_75 = new JSeparator();
		separator_75.setBounds(1123, 119, 9, 1);
		frame.getContentPane().add(separator_75);
		
		JSeparator separator_76 = new JSeparator();
		separator_76.setBounds(1123, 154, 9, 1);
		frame.getContentPane().add(separator_76);
		
		JSeparator separator_77 = new JSeparator();
		separator_77.setBounds(1123, 189, 9, 1);
		frame.getContentPane().add(separator_77);
		
		JSeparator separator_78 = new JSeparator();
		separator_78.setBounds(1123, 224, 9, 1);
		frame.getContentPane().add(separator_78);
		
		JSeparator separator_79 = new JSeparator();
		separator_79.setBounds(1123, 259, 9, 1);
		frame.getContentPane().add(separator_79);
		
		ArrayList<JButton> roundOneRightSideJButtons = getJButtonOpeningRoundData(32, 12);
		
		roundOneRightSideJButtons.get(0).setBounds(1132, 0, 80, 15);
		roundOneRightSideJButtons.get(1).setBounds(1132, 15, 80, 15);
		roundOneRightSideJButtons.get(2).setBounds(1132, 35, 80, 15);
		roundOneRightSideJButtons.get(3).setBounds(1132, 50, 80, 15);
		roundOneRightSideJButtons.get(4).setBounds(1132, 70, 80, 15);
		roundOneRightSideJButtons.get(5).setBounds(1132, 85, 80, 15);
		roundOneRightSideJButtons.get(6).setBounds(1132, 105, 80, 15);
		roundOneRightSideJButtons.get(7).setBounds(1132, 120, 80, 15);
		roundOneRightSideJButtons.get(8).setBounds(1132, 140, 80, 15);
		roundOneRightSideJButtons.get(9).setBounds(1132, 155, 80, 15);
		roundOneRightSideJButtons.get(10).setBounds(1132, 175, 80, 15);
		roundOneRightSideJButtons.get(11).setBounds(1132, 190, 80, 15);
		roundOneRightSideJButtons.get(12).setBounds(1132, 210, 80, 15);
		roundOneRightSideJButtons.get(13).setBounds(1132, 225, 80, 15);
		roundOneRightSideJButtons.get(14).setBounds(1132, 245, 80, 15);
		roundOneRightSideJButtons.get(15).setBounds(1132, 260, 80, 15);
		roundOneRightSideJButtons.get(15).setFont(new Font("Tahoma", Font.PLAIN, 8));
		roundOneRightSideJButtons.get(16).setBounds(1132, 343, 80, 15);
		roundOneRightSideJButtons.get(17).setBounds(1132, 358, 80, 15);
		roundOneRightSideJButtons.get(18).setBounds(1132, 378, 80, 15);
		roundOneRightSideJButtons.get(19).setBounds(1132, 393, 80, 15);
		roundOneRightSideJButtons.get(20).setBounds(1132, 413, 80, 15);
		roundOneRightSideJButtons.get(21).setBounds(1132, 428, 80, 15);
		roundOneRightSideJButtons.get(22).setBounds(1132, 448, 80, 15);
		roundOneRightSideJButtons.get(23).setBounds(1132, 463, 80, 15);
		roundOneRightSideJButtons.get(24).setBounds(1132, 483, 80, 15);
		roundOneRightSideJButtons.get(25).setFont(new Font("Tahoma", Font.PLAIN, 8));
		roundOneRightSideJButtons.get(25).setBounds(1132, 498, 80, 15);
		roundOneRightSideJButtons.get(26).setBounds(1132, 518, 80, 15);
		roundOneRightSideJButtons.get(27).setBounds(1132, 533, 80, 15);
		roundOneRightSideJButtons.get(28).setBounds(1132, 553, 80, 15);
		roundOneRightSideJButtons.get(29).setBounds(1132, 568, 80, 15);
		roundOneRightSideJButtons.get(30).setBounds(1132, 588, 80, 15);
		roundOneRightSideJButtons.get(31).setBounds(1132, 603, 80, 15);
		
		for(int x = 0; x < roundOneRightSideJButtons.size(); x++) {
			frame.getContentPane().add(roundOneRightSideJButtons.get(x));
		}
		
		
		
		ArrayList<JButton> roundTwoRightSideJButtons = new ArrayList<>();
		for(int x = 0; x < 16; x++) {
			
			JButton button = new JButton("");
			button.setFont(new Font("Tahoma", Font.PLAIN, 9));
			
			final int j = x;
			button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null; 
		    
		           	if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[j * 2][12], bracket.bracket[j * 2 + 1][12]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[j * 2][12], bracket.bracket[j * 2 + 1][12]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[j * 2][12], bracket.bracket[j * 2 + 1][12]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[j * 2][12], bracket.bracket[j * 2 + 1][12]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[j * 2][12], bracket.bracket[j * 2 + 1][12]);
		            }
		            bracket.bracket[j][11] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
			}
		});
			roundTwoRightSideJButtons.add(button);
		};
		
		roundTwoRightSideJButtons.get(0).setBounds(1043, 7, 80, 15);
		roundTwoRightSideJButtons.get(1).setBounds(1043, 42, 80, 15);
		roundTwoRightSideJButtons.get(2).setBounds(1043, 77 , 80, 15);
		roundTwoRightSideJButtons.get(3).setBounds(1043, 112, 80, 15);
		roundTwoRightSideJButtons.get(4).setBounds(1043, 147, 80, 15);
		roundTwoRightSideJButtons.get(5).setBounds(1043, 182, 80, 15);
		roundTwoRightSideJButtons.get(6).setBounds(1043, 217, 80, 15);
		roundTwoRightSideJButtons.get(7).setBounds(1043, 252, 80, 15);
		roundTwoRightSideJButtons.get(8).setBounds(1043, 350, 80, 15);
		roundTwoRightSideJButtons.get(9).setBounds(1043, 385, 80, 15);
		roundTwoRightSideJButtons.get(10).setBounds(1043, 420, 80, 15);
		roundTwoRightSideJButtons.get(11).setBounds(1043, 455, 80, 15);
		roundTwoRightSideJButtons.get(12).setBounds(1043, 490, 80, 15);
		roundTwoRightSideJButtons.get(13).setBounds(1043, 525, 80, 15);
		roundTwoRightSideJButtons.get(14).setBounds(1043, 560, 80, 15);
		roundTwoRightSideJButtons.get(15).setBounds(1043, 595, 80, 15);
		for(int x = 0; x < 16; x++) {
			frame.getContentPane().add(roundTwoRightSideJButtons.get(x));
		}
	
		
		
		JSeparator separator_80 = new JSeparator();
		separator_80.setBounds(1034, 14, 9, 1);
		frame.getContentPane().add(separator_80);
		
		JSeparator separator_81 = new JSeparator();
		separator_81.setBounds(1034, 49, 9, 1);
		frame.getContentPane().add(separator_81);
		
		JSeparator separator_82 = new JSeparator();
		separator_82.setBounds(1034, 84, 9, 1);
		frame.getContentPane().add(separator_82);
		
		JSeparator separator_83 = new JSeparator();
		separator_83.setBounds(1034, 119, 9, 1);
		frame.getContentPane().add(separator_83);
		
		JSeparator separator_84 = new JSeparator();
		separator_84.setBounds(1034, 154, 9, 1);
		frame.getContentPane().add(separator_84);
		
		JSeparator separator_85 = new JSeparator();
		separator_85.setBounds(1034, 189, 9, 1);
		frame.getContentPane().add(separator_85);
		
		JSeparator separator_86 = new JSeparator();
		separator_86.setBounds(1034, 224, 9, 1);
		frame.getContentPane().add(separator_86);
		
		JSeparator separator_87 = new JSeparator();
		separator_87.setBounds(1034, 259, 9, 1);
		frame.getContentPane().add(separator_87);
		
		JSeparator separator_88 = new JSeparator();
		separator_88.setOrientation(SwingConstants.VERTICAL);
		separator_88.setBounds(1034, 14, 2, 36);
		frame.getContentPane().add(separator_88);
		
		JSeparator separator_89 = new JSeparator();
		separator_89.setOrientation(SwingConstants.VERTICAL);
		separator_89.setBounds(1034, 84, 2, 36);
		frame.getContentPane().add(separator_89);
		
		JSeparator separator_90 = new JSeparator();
		separator_90.setOrientation(SwingConstants.VERTICAL);
		separator_90.setBounds(1034, 154, 5, 36);
		frame.getContentPane().add(separator_90);
		
		JSeparator separator_91 = new JSeparator();
		separator_91.setOrientation(SwingConstants.VERTICAL);
		separator_91.setBounds(1034, 224, 5, 36);
		frame.getContentPane().add(separator_91);
		
		JSeparator separator_92 = new JSeparator();
		separator_92.setBounds(1019, 31, 15, 1);
		frame.getContentPane().add(separator_92);
		
		JSeparator separator_93 = new JSeparator();
		separator_93.setBounds(1019, 100, 15, 1);
		frame.getContentPane().add(separator_93);
		
		JSeparator separator_94 = new JSeparator();
		separator_94.setBounds(1019, 170, 15, 1);
		frame.getContentPane().add(separator_94);
		
		JSeparator separator_95 = new JSeparator();
		separator_95.setBounds(1019, 240, 15, 1);
		frame.getContentPane().add(separator_95);
		
		
		ArrayList<JButton> roundThreeRightSideJButtons = new ArrayList<>();
		for(int x = 0; x < 8; x++) {
			
			JButton button = new JButton("");
			button.setFont(new Font("Tahoma", Font.PLAIN, 9));
			
			final int j = x;
			button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (bracket.bracket[j * 2][11] == null || bracket.bracket[j * 2 + 1][11] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null; 
		    
		           	if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[j * 2][11], bracket.bracket[j * 2 + 1][11]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[j * 2][11], bracket.bracket[j * 2 + 1][11]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[j * 2][11], bracket.bracket[j * 2 + 1][11]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[j * 2][11], bracket.bracket[j * 2 + 1][11]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[j * 2][11], bracket.bracket[j * 2 + 1][11]);
		            }
		            bracket.bracket[j][10] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button.setText("(" + winnerSeed + ")" + " " + winnerName);
				}       
			}
		});
			roundThreeRightSideJButtons.add(button);
		};
		
		roundThreeRightSideJButtons.get(0).setBounds(939, 24, 80, 15);
		roundThreeRightSideJButtons.get(1).setBounds(939, 93, 80, 15);
		roundThreeRightSideJButtons.get(2).setBounds(939, 163, 80, 15);
		roundThreeRightSideJButtons.get(3).setBounds(939, 233, 80, 15);
		roundThreeRightSideJButtons.get(4).setBounds(939, 367, 80, 15);
		roundThreeRightSideJButtons.get(5).setBounds(939, 436, 80, 15);
		roundThreeRightSideJButtons.get(6).setBounds(939, 506, 80, 15);
		roundThreeRightSideJButtons.get(7).setBounds(939, 576, 80, 15);
		
		for(int x = 0; x < 8; x++) {
			frame.getContentPane().add(roundThreeRightSideJButtons.get(x));
		}
		
		
		

		
		JSeparator separator_96 = new JSeparator();
		separator_96.setBounds(924, 31, 15, 1);
		frame.getContentPane().add(separator_96);
		
		JSeparator separator_97 = new JSeparator();
		separator_97.setBounds(924, 100, 15, 1);
		frame.getContentPane().add(separator_97);
		
		JSeparator separator_98 = new JSeparator();
		separator_98.setBounds(924, 170, 15, 1);
		frame.getContentPane().add(separator_98);
		
		JSeparator separator_99 = new JSeparator();
		separator_99.setBounds(924, 240, 15, 1);
		frame.getContentPane().add(separator_99);
		
		JSeparator separator_100 = new JSeparator();
		separator_100.setOrientation(SwingConstants.VERTICAL);
		separator_100.setBounds(924, 31, 1, 69);
		frame.getContentPane().add(separator_100);
		
		JSeparator separator_101 = new JSeparator();
		separator_101.setOrientation(SwingConstants.VERTICAL);
		separator_101.setBounds(924, 171, 1, 69);
		frame.getContentPane().add(separator_101);
		
		JSeparator separator_102 = new JSeparator();
		separator_102.setBounds(909, 65, 15, 1);
		frame.getContentPane().add(separator_102);
		
		
		
		ArrayList<JButton> roundFourRightSideJButtons = new ArrayList<>();
		for(int x = 0; x < 4; x++) {
			
			JButton button = new JButton("");
			button.setFont(new Font("Tahoma", Font.PLAIN, 9));
			
			final int j = x;
			button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (bracket.bracket[j * 2][10] == null || bracket.bracket[j * 2 + 1][10] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null; 
		    
		           	if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[j * 2][10], bracket.bracket[j * 2 + 1][10]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[j * 2][10], bracket.bracket[j * 2 + 1][10]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[j * 2][10], bracket.bracket[j * 2 + 1][10]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[j * 2][10], bracket.bracket[j * 2 + 1][10]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[j * 2][10], bracket.bracket[j * 2 + 1][10]);
		            }
		            bracket.bracket[j][9] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button.setText("(" + winnerSeed + ")" + " " + winnerName);
				}       
			}
		});
			roundFourRightSideJButtons.add(button);
		};
		
		roundFourRightSideJButtons.get(0).setBounds(829, 59, 80, 15);
		roundFourRightSideJButtons.get(1).setBounds(829, 198, 80, 15);
		roundFourRightSideJButtons.get(2).setBounds(829, 402, 80, 15);
		roundFourRightSideJButtons.get(3).setBounds(829, 541, 80, 15);
		
		
		for(int x = 0; x < 4; x++) {
			frame.getContentPane().add(roundFourRightSideJButtons.get(x));
		}

		
		JSeparator separator_103 = new JSeparator();
		separator_103.setBounds(909, 205, 15, 1);
		frame.getContentPane().add(separator_103);
		

		
		JSeparator separator_104 = new JSeparator();
		separator_104.setBounds(814, 65, 15, 1);
		frame.getContentPane().add(separator_104);
		
		JSeparator separator_105 = new JSeparator();
		separator_105.setBounds(814, 205, 15, 1);
		frame.getContentPane().add(separator_105);
		
		JSeparator separator_106 = new JSeparator();
		separator_106.setOrientation(SwingConstants.VERTICAL);
		separator_106.setBounds(814, 65, 1, 140);
		frame.getContentPane().add(separator_106);
		
		JSeparator separator_107 = new JSeparator();
		separator_107.setBounds(799, 135, 15, 2);
		frame.getContentPane().add(separator_107);
		
		JButton button_92 = new JButton("");
		button_92.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_92.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bracket.bracket[0][9] == null || bracket.bracket[1][9] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null;
		           	int x = 0;
		           	int y = 9;
		           	int a = 1;
		           	int b = 9;
		            if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            bracket.bracket[0][8] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button_92.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
				}
			}
		});
		button_92.setBounds(719, 129, 80, 15);
		frame.getContentPane().add(button_92);
		


		
		JSeparator separator_108 = new JSeparator();
		separator_108.setBounds(1123, 357, 9, 1);
		frame.getContentPane().add(separator_108);
		
		JSeparator separator_109 = new JSeparator();
		separator_109.setBounds(1123, 392, 9, 1);
		frame.getContentPane().add(separator_109);
		
		JSeparator separator_110 = new JSeparator();
		separator_110.setBounds(1123, 427, 9, 1);
		frame.getContentPane().add(separator_110);
		
		JSeparator separator_111 = new JSeparator();
		separator_111.setBounds(1123, 462, 9, 1);
		frame.getContentPane().add(separator_111);
		
		JSeparator separator_112 = new JSeparator();
		separator_112.setBounds(1123, 497, 9, 1);
		frame.getContentPane().add(separator_112);
		
		JSeparator separator_113 = new JSeparator();
		separator_113.setBounds(1123, 532, 9, 1);
		frame.getContentPane().add(separator_113);
		
		JSeparator separator_114 = new JSeparator();
		separator_114.setBounds(1123, 567, 9, 1);
		frame.getContentPane().add(separator_114);
		
		JSeparator separator_115 = new JSeparator();
		separator_115.setBounds(1123, 602, 9, 1);
		frame.getContentPane().add(separator_115);
	
		
		JSeparator separator_116 = new JSeparator();
		separator_116.setBounds(1034, 357, 9, 1);
		frame.getContentPane().add(separator_116);
		
		JSeparator separator_117 = new JSeparator();
		separator_117.setBounds(1034, 392, 9, 1);
		frame.getContentPane().add(separator_117);
		
		JSeparator separator_118 = new JSeparator();
		separator_118.setBounds(1034, 427, 9, 1);
		frame.getContentPane().add(separator_118);
		
		JSeparator separator_119 = new JSeparator();
		separator_119.setBounds(1034, 462, 9, 1);
		frame.getContentPane().add(separator_119);
		
		JSeparator separator_120 = new JSeparator();
		separator_120.setBounds(1034, 497, 9, 1);
		frame.getContentPane().add(separator_120);
		
		JSeparator separator_121 = new JSeparator();
		separator_121.setBounds(1034, 532, 9, 1);
		frame.getContentPane().add(separator_121);
		
		JSeparator separator_122 = new JSeparator();
		separator_122.setBounds(1034, 567, 9, 1);
		frame.getContentPane().add(separator_122);
		
		JSeparator separator_123 = new JSeparator();
		separator_123.setBounds(1034, 602, 9, 1);
		frame.getContentPane().add(separator_123);
		
		JSeparator separator_124 = new JSeparator();
		separator_124.setOrientation(SwingConstants.VERTICAL);
		separator_124.setBounds(1034, 357, 2, 36);
		frame.getContentPane().add(separator_124);
		
		JSeparator separator_125 = new JSeparator();
		separator_125.setOrientation(SwingConstants.VERTICAL);
		separator_125.setBounds(1034, 427, 2, 36);
		frame.getContentPane().add(separator_125);
		
		JSeparator separator_126 = new JSeparator();
		separator_126.setOrientation(SwingConstants.VERTICAL);
		separator_126.setBounds(1034, 497, 5, 36);
		frame.getContentPane().add(separator_126);
		
		JSeparator separator_127 = new JSeparator();
		separator_127.setOrientation(SwingConstants.VERTICAL);
		separator_127.setBounds(1034, 567, 5, 36);
		frame.getContentPane().add(separator_127);
		
		JSeparator separator_128 = new JSeparator();
		separator_128.setBounds(1019, 374, 15, 1);
		frame.getContentPane().add(separator_128);
		
		JSeparator separator_129 = new JSeparator();
		separator_129.setBounds(1019, 443, 15, 1);
		frame.getContentPane().add(separator_129);
		
		JSeparator separator_130 = new JSeparator();
		separator_130.setBounds(1019, 513, 15, 1);
		frame.getContentPane().add(separator_130);
		
		JSeparator separator_131 = new JSeparator();
		separator_131.setBounds(1019, 583, 15, 1);
		frame.getContentPane().add(separator_131);
		

		
		JSeparator separator_132 = new JSeparator();
		separator_132.setBounds(924, 374, 15, 1);
		frame.getContentPane().add(separator_132);
		
		JSeparator separator_133 = new JSeparator();
		separator_133.setBounds(924, 443, 15, 1);
		frame.getContentPane().add(separator_133);
		
		JSeparator separator_134 = new JSeparator();
		separator_134.setBounds(924, 513, 15, 1);
		frame.getContentPane().add(separator_134);
		
		JSeparator separator_135 = new JSeparator();
		separator_135.setBounds(924, 583, 15, 1);
		frame.getContentPane().add(separator_135);
		
		JSeparator separator_136 = new JSeparator();
		separator_136.setOrientation(SwingConstants.VERTICAL);
		separator_136.setBounds(924, 374, 1, 69);
		frame.getContentPane().add(separator_136);
		
		JSeparator separator_137 = new JSeparator();
		separator_137.setOrientation(SwingConstants.VERTICAL);
		separator_137.setBounds(924, 514, 1, 69);
		frame.getContentPane().add(separator_137);
		
		JSeparator separator_138 = new JSeparator();
		separator_138.setBounds(909, 408, 15, 1);
		frame.getContentPane().add(separator_138);
		

		
		JSeparator separator_139 = new JSeparator();
		separator_139.setBounds(909, 548, 15, 1);
		frame.getContentPane().add(separator_139);
		

		
		JSeparator separator_140 = new JSeparator();
		separator_140.setBounds(814, 408, 15, 1);
		frame.getContentPane().add(separator_140);
		
		JSeparator separator_141 = new JSeparator();
		separator_141.setBounds(814, 548, 15, 1);
		frame.getContentPane().add(separator_141);
		
		JSeparator separator_142 = new JSeparator();
		separator_142.setOrientation(SwingConstants.VERTICAL);
		separator_142.setBounds(814, 408, 1, 140);
		frame.getContentPane().add(separator_142);
		
		JSeparator separator_143 = new JSeparator();
		separator_143.setBounds(799, 478, 15, 2);
		frame.getContentPane().add(separator_143);
		
		JButton button_123 = new JButton("");
		button_123.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_123.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bracket.bracket[2][9] == null || bracket.bracket[3][9] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null;
		           	int x = 2;
		           	int y = 9;
		           	int a = 3;
		           	int b = 9;
		            if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            bracket.bracket[1][8] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button_123.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
				}
			}
		});
		button_123.setBounds(719, 472, 80, 15);
		frame.getContentPane().add(button_123);
		
		JSeparator separator_144 = new JSeparator();
		separator_144.setBounds(493, 135, 15, 1);
		frame.getContentPane().add(separator_144);
		
		JSeparator separator_145 = new JSeparator();
		separator_145.setBounds(493, 478, 15, 1);
		frame.getContentPane().add(separator_145);
		
		JSeparator separator_146 = new JSeparator();
		separator_146.setOrientation(SwingConstants.VERTICAL);
		separator_146.setBounds(508, 135, 1, 344);
		frame.getContentPane().add(separator_146);
		
		JSeparator separator_147 = new JSeparator();
		separator_147.setBounds(704, 135, 15, 1);
		frame.getContentPane().add(separator_147);
		
		JSeparator separator_148 = new JSeparator();
		separator_148.setBounds(704, 478, 15, 1);
		frame.getContentPane().add(separator_148);
		
		JSeparator separator_149 = new JSeparator();
		separator_149.setOrientation(SwingConstants.VERTICAL);
		separator_149.setBounds(704, 135, 1, 344);
		frame.getContentPane().add(separator_149);
		
		JSeparator separator_150 = new JSeparator();
		separator_150.setBounds(508, 170, 30, 2);
		frame.getContentPane().add(separator_150);
		
		JButton button_124 = new JButton("");
		button_124.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_124.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bracket.bracket[0][4] == null || bracket.bracket[1][4] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null;
		           	int x = 0;
		           	int y = 4;
		           	int a = 1;
		           	int b = 4;
		            if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            bracket.bracket[0][5] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button_124.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
				}
			}
		});
		button_124.setBounds(538, 163, 80, 15);
		frame.getContentPane().add(button_124);
		
		JSeparator separator_151 = new JSeparator();
		separator_151.setBounds(674, 443, 30, 2);
		frame.getContentPane().add(separator_151);
		
		JButton button_125 = new JButton("");
		button_125.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_125.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bracket.bracket[0][8] == null || bracket.bracket[1][8] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null;
		           	int x = 0;
		           	int y = 8;
		           	int a = 1;
		           	int b = 8;
		            if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            bracket.bracket[0][7] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button_125.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
				}
			}
		});
		button_125.setBounds(594, 437, 80, 15);
		frame.getContentPane().add(button_125);
		
		JSeparator separator_152 = new JSeparator();
		separator_152.setOrientation(SwingConstants.VERTICAL);
		separator_152.setBounds(606, 178, 1, 100);
		frame.getContentPane().add(separator_152);
		
		JSeparator separator_153 = new JSeparator();
		separator_153.setOrientation(SwingConstants.VERTICAL);
		separator_153.setBounds(606, 337, 1, 100);
		frame.getContentPane().add(separator_153);
		
		JButton button_126 = new JButton("");
		button_126.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bracket.bracket[0][5] == null || bracket.bracket[0][7] == null) {
					JOptionPane.showMessageDialog(null, "Please complete all preceding matchups before simulating this one!");
					}
				else {
				
				String[] options = {"Win Rating Algorithm", "Historical Probability", "Historical Probability + FG%", "Historical Probability + 3PT%", "Historical Probability + FT%"}; 
				 
		           String result = (String)JOptionPane.showInputDialog(
		               frame,
		               "How would you like to simulate this matchup?", 
		               "Matchup Simulator",            
		               JOptionPane.PLAIN_MESSAGE,
		               null,            
		               options, 
		               options[0] 
		            );
		           	Team winner = null;
		           	int x = 0;
		           	int y = 5;
		           	int a = 0;
		           	int b = 7;
		            if (result == "Win Rating Algorithm") {
		            	winner = myMS.getWinnerByWinRating(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability") {
		            	winner = myMS.getWinnerHistoricalPerc(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FG%") {
		            	winner = myMS.getWinnerWithFGPercFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + 3PT%") {
		            	winner = myMS.getWinnerWith3PtShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            if (result == "Historical Probability + FT%") {
		            	winner = myMS.getWinnerWithFoulShootingFocus(bracket.bracket[x][y], bracket.bracket[a][b]);
		            }
		            bracket.bracket[0][6] = winner;
	            	String winnerSeed = String.valueOf(winner.getSeedNumber());
	            	String winnerName = winner.getShortName();
	            	button_126.setText("(" + winnerSeed + ")" + " " + winnerName);
		            
				}
			}
		});
		button_126.setBounds(565, 278, 80, 59);
		frame.getContentPane().add(button_126);
		
		txtMarchMadnessBracket = new JTextField();
		txtMarchMadnessBracket.setHorizontalAlignment(SwingConstants.CENTER);
		txtMarchMadnessBracket.setForeground(Color.RED);
		txtMarchMadnessBracket.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 23));
		txtMarchMadnessBracket.setText("March Madness");
		txtMarchMadnessBracket.setBounds(428, 48, 358, 52);
		frame.getContentPane().add(txtMarchMadnessBracket);
		txtMarchMadnessBracket.setColumns(10);
		
		txtBracketBuilder = new JTextField();
		txtBracketBuilder.setText("Bracket Builder 2020");
		txtBracketBuilder.setHorizontalAlignment(SwingConstants.CENTER);
		txtBracketBuilder.setForeground(Color.BLUE);
		txtBracketBuilder.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 23));
		txtBracketBuilder.setColumns(10);
		txtBracketBuilder.setBounds(428, 531, 358, 52);
		frame.getContentPane().add(txtBracketBuilder);

	}
	
	/**
	 * This method populates the opening round of sixty-four teams, 32 teams on each end of the bracket. This method is called twice, once for the left
	 * side and another for the right. 
	 * @param numberOfRowsInBracket
	 * @param bracketColumn
	 * @return
	 */
	public  ArrayList<JButton> getJButtonOpeningRoundData(int numberOfRowsInBracket, int bracketColumn){
		
		ArrayList<JButton> openingRoundJButtons = new ArrayList<JButton>();
		for(int x = 0; x < numberOfRowsInBracket; x++) {
			
		final int y = x;
		JButton button = new JButton("(" + bracket.bracket[y][bracketColumn].getSeedNumber() + ") " + bracket.bracket[y][bracketColumn].getShortName());
		button.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(null, bracket.bracket[y][bracketColumn].getSchoolName() + "\n" + "Record: " + (int)bracket.bracket[y][bracketColumn].getWins() + "-" + (int)bracket.bracket[y][bracketColumn].getLosses()
						+ "\n" + "Win Rating: " + bracket.bracket[y][bracketColumn].getWinRating() + "\n" + "SoS: " + bracket.bracket[y][bracketColumn].getStrengthOfSchedule() + "\n" + "FG%: " +
						bracket.bracket[y][bracketColumn].getFieldGoalPercentage() + "\n" + "3PT%: " + bracket.bracket[y][bracketColumn].getThreePointerPercentage() + "\n" + "FT%: " + bracket.bracket[y][bracketColumn].getFreeThrowPercentage());
				}
		});
		openingRoundJButtons.add(button);
		}
		
		return openingRoundJButtons;
	}
	
	
}