/**
 * MatchupSimulatorTest is a tester class for MatchupSimulator and the associated methods it calls from the Team class.
 * @author Jordan Mabalatan
 * 
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MatchupSimulatorTest {
   
    @Test
    void testGetWinnerHistoricalPerc() {
        
        Team team1 = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        Team team2 = new Team("Georgetown","GTWN","South",16,0.456,32,15,17,0.469,9.6,1280,840,1921,0.437,206,595,0.346,503,652,0.771,375,847,1222,479,200,130,433,511);
        MatchupSimulator matchSim = new MatchupSimulator();
        Team winningTeam = matchSim.getWinnerHistoricalPerc(team1, team2);
        assertEquals(team1.getSchoolName(), winningTeam.getSchoolName());
        
    }   
    
    @Test
    void testGetWinnerWithFGPercFocus() {
        
        Team team1 = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        Team team2 = new Team("Georgetown","GTWN","South",16,0.456,32,15,17,0.469,9.6,1280,840,1921,0,206,595,0.346,503,652,0.771,375,847,1222,479,200,130,433,511);
        MatchupSimulator matchSim = new MatchupSimulator();
        Team winningTeam = matchSim.getWinnerWithFGPercFocus(team1, team2);
        assertEquals(team1.getSchoolName(), winningTeam.getSchoolName());
        
    } 
    
    @Test
    void testGetWinnerWith3PtShootingFocus() {
        
        Team team1 = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        Team team2 = new Team("Georgetown","GTWN","South",16,0.456,32,15,17,0.469,9.6,1280,840,1921,0.437,206,595,0,503,652,0.771,375,847,1222,479,200,130,433,511);
        MatchupSimulator matchSim = new MatchupSimulator();
        Team winningTeam = matchSim.getWinnerWith3PtShootingFocus(team1, team2);
        assertEquals(team1.getSchoolName(), winningTeam.getSchoolName());
        
    }  
    
    @Test
    void testGetWinnerWithFoulShootingFocus() {
        
        Team team1 = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        Team team2 = new Team("Georgetown","GTWN","South",16,0.456,32,15,17,0.469,9.6,1280,840,1921,0.437,206,595,0.346,503,652,0,375,847,1222,479,200,130,433,511);
        MatchupSimulator matchSim = new MatchupSimulator();
        Team winningTeam = matchSim.getWinnerWithFoulShootingFocus(team1, team2);
        assertEquals(team1.getSchoolName(), winningTeam.getSchoolName());
        
    }  
     
    @Test
    void testGetWinnerByWinRating() {
        
        Team team1 = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        Team team2 = new Team("Georgetown","GTWN","South",16,0,32,15,17,0.469,9.6,1280,840,1921,0.437,206,595,0.346,503,652,0.771,375,847,1222,479,200,130,433,511);
        MatchupSimulator matchSim = new MatchupSimulator();
        Team winningTeam = matchSim.getWinnerByWinRating(team1, team2);
        assertEquals(team1.getSchoolName(), winningTeam.getSchoolName());
        
    }
    
    @Test
    void testGetFieldGoalPercentage() {
        
        Team duke = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        assertEquals((duke.getFieldGoals() / duke.getFieldGoalsAttempted()), duke.getFieldGoalPercentage(), 0.1);
        
    }
    
    @Test
    void testGetThreePointerPercentage() {
        
        Team duke = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        assertEquals((duke.getThreePointers() / duke.getThreePointersAttempted()), duke.getThreePointerPercentage(), 0.1);
        
    }
    
    @Test
    void testGetFreeThrowPercentage() {
        
        Team duke = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        assertEquals((duke.getFreeThrows() / duke.getFreeThrowsAttempted()), duke.getFreeThrowPercentage(), 0.1);
        
    }
    
    @Test
    void testGetTotalRebounds() {
        
        Team duke = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        assertEquals((duke.getOffensiveRebounds() + duke.getDefensiveRebounds()), duke.getTotalRebounds(), 0.1); 
        
    }
    
    @Test
    void testGetGamesPlayed() {
        
        Team duke = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        assertEquals((duke.getWins() + duke.getLosses()), duke.getGamesPlayed(), 0.1); 
        
    }
    
    @Test
    void testWinLossPercentage() {
        
        Team duke = new Team("Duke","DUKE","South",1,0.9418,31,25,6,0.806,8.01,1260,920,1957,0.47,217,617,0.352,501,696,0.72,394,850,1244,479,258,188,409,557);
        assertEquals((duke.getWins() / duke.getGamesPlayed()), duke.getWinLossPercentage(), 0.1); 
        
    }
    
}
