/**
 * This class runs the simulation of a game in NCAA tournament by using historical win percentage
 * for a given seed. The percentage odds of a given team is weighed by methods that will, by
 * using statistical season data, apply different metrics to adjust the odds. 
 * @author dweis
 * 
 */

public class MatchupSimulator {
	
	public Double getHistoricalWinPerc(Team team1, Team team2) {
		
		Double[][] seedHistoryPercGrid = new Double[16][16];
		seedHistoryPercGrid[0][0] = 50.0;
		seedHistoryPercGrid[0][1] = 53.3;
		seedHistoryPercGrid[0][2] = 62.5;
		seedHistoryPercGrid[0][3] = 70.7;
		seedHistoryPercGrid[0][4] = 83.3;
		seedHistoryPercGrid[0][5] = 68.8;
		seedHistoryPercGrid[0][6] = 85.7;
		seedHistoryPercGrid[0][7] = 80.2;
		seedHistoryPercGrid[0][8] = 90.0;
		seedHistoryPercGrid[0][9] = 85.7;
		seedHistoryPercGrid[0][10] = 57.1;
		seedHistoryPercGrid[0][11] = 100.0;
		seedHistoryPercGrid[0][12] = 100.0;
		seedHistoryPercGrid[0][13] = 100.0;
		seedHistoryPercGrid[0][14] = 100.0;
		seedHistoryPercGrid[0][15] = 99.3;
		
		seedHistoryPercGrid[1][0] = 46.7;
		seedHistoryPercGrid[1][1] = 50.0;
		seedHistoryPercGrid[1][2] = 60.3;
		seedHistoryPercGrid[1][3] = 44.4;
		seedHistoryPercGrid[1][4] = 16.7;
		seedHistoryPercGrid[1][5] = 72.2;
		seedHistoryPercGrid[1][6] = 70.1;
		seedHistoryPercGrid[1][7] = 44.4;
		seedHistoryPercGrid[1][8] = 50.0;
		seedHistoryPercGrid[1][9] = 63.3;
		seedHistoryPercGrid[1][10] = 87.5;
		seedHistoryPercGrid[1][11] = 100.0;
		seedHistoryPercGrid[1][12] = 94.3;
		seedHistoryPercGrid[1][13] = 94.3;
		seedHistoryPercGrid[1][14] = 94.3;
		seedHistoryPercGrid[1][15] = 94.3;
		
		seedHistoryPercGrid[2][0] = 37.5;
		seedHistoryPercGrid[2][1] = 39.7;
		seedHistoryPercGrid[2][2] = 50.0;
		seedHistoryPercGrid[2][3] = 62.5;
		seedHistoryPercGrid[2][4] = 50.0;
		seedHistoryPercGrid[2][5] = 57.8;
		seedHistoryPercGrid[2][6] = 61.1;
		seedHistoryPercGrid[2][7] = 100.0;
		seedHistoryPercGrid[2][8] = 100.0;
		seedHistoryPercGrid[2][9] = 69.2;
		seedHistoryPercGrid[2][10] = 69.1;
		seedHistoryPercGrid[2][11] = 85.0;
		seedHistoryPercGrid[2][12] = 85.0;
		seedHistoryPercGrid[2][13] = 85.0;
		seedHistoryPercGrid[2][14] = 100.0;
		seedHistoryPercGrid[2][15] = 100.0;
		
		seedHistoryPercGrid[3][0] = 29.3;
		seedHistoryPercGrid[3][1] = 55.6;
		seedHistoryPercGrid[3][2] = 37.5;
		seedHistoryPercGrid[3][3] = 50.0;
		seedHistoryPercGrid[3][4] = 55.8;
		seedHistoryPercGrid[3][5] = 33.3;
		seedHistoryPercGrid[3][6] = 33.3;
		seedHistoryPercGrid[3][7] = 36.4;
		seedHistoryPercGrid[3][8] = 50.0;
		seedHistoryPercGrid[3][9] = 100.0;
		seedHistoryPercGrid[3][10] = 70.7;
		seedHistoryPercGrid[3][11] = 70.7;
		seedHistoryPercGrid[3][12] = 79.9;
		seedHistoryPercGrid[3][13] = 79.9;
		seedHistoryPercGrid[3][14] = 79.9;
		seedHistoryPercGrid[3][15] = 79.9;
		
		seedHistoryPercGrid[4][0] = 16.7;
		seedHistoryPercGrid[4][1] = 83.3;
		seedHistoryPercGrid[4][2] = 50.0;
		seedHistoryPercGrid[4][3] = 44.2;
		seedHistoryPercGrid[4][4] = 50.0;
		seedHistoryPercGrid[4][5] = 50.0;
		seedHistoryPercGrid[4][6] = 25.0;
		seedHistoryPercGrid[4][7] = 25.0;
		seedHistoryPercGrid[4][8] = 25.0;
		seedHistoryPercGrid[4][9] = 100.0;
		seedHistoryPercGrid[4][10] = 66.9;
		seedHistoryPercGrid[4][11] = 82.4;
		seedHistoryPercGrid[4][12] = 82.4;
		seedHistoryPercGrid[4][13] = 82.4;
		seedHistoryPercGrid[4][14] = 82.4;
		seedHistoryPercGrid[4][15] = 82.4;
		
		seedHistoryPercGrid[5][0] = 31.3;
		seedHistoryPercGrid[5][1] = 27.8;
		seedHistoryPercGrid[5][2] = 42.2;
		seedHistoryPercGrid[5][3] = 66.7;
		seedHistoryPercGrid[5][4] = 62.5;
		seedHistoryPercGrid[5][5] = 50.0;
		seedHistoryPercGrid[5][6] = 62.5;
		seedHistoryPercGrid[5][7] = 25.0;
		seedHistoryPercGrid[5][8] = 60.0;
		seedHistoryPercGrid[5][9] = 60.0;
		seedHistoryPercGrid[5][10] = 63.8;
		seedHistoryPercGrid[5][11] = 63.8;
		seedHistoryPercGrid[5][12] = 63.8;
		seedHistoryPercGrid[5][13] = 87.5;
		seedHistoryPercGrid[5][14] = 87.5;
		seedHistoryPercGrid[5][15] = 87.5;
		
		seedHistoryPercGrid[6][0] = 14.3;
		seedHistoryPercGrid[6][1] = 29.9;
		seedHistoryPercGrid[6][2] = 38.9;
		seedHistoryPercGrid[6][3] = 66.7;
		seedHistoryPercGrid[6][4] = 37.5;
		seedHistoryPercGrid[6][5] = 37.5;
		seedHistoryPercGrid[6][6] = 50.0;
		seedHistoryPercGrid[6][7] = 50.0;
		seedHistoryPercGrid[6][8] = 60.4;
		seedHistoryPercGrid[6][9] = 60.4;
		seedHistoryPercGrid[6][10] = 60.4;
		seedHistoryPercGrid[6][11] = 60.4;
		seedHistoryPercGrid[6][12] = 60.4;
		seedHistoryPercGrid[6][13] = 60.4;
		seedHistoryPercGrid[6][14] = 60.4;
		seedHistoryPercGrid[6][15] = 60.4;
		
		seedHistoryPercGrid[7][0] = 19.8;
		seedHistoryPercGrid[7][1] = 55.6;
		seedHistoryPercGrid[7][2] = 55.6;
		seedHistoryPercGrid[7][3] = 63.6;
		seedHistoryPercGrid[7][4] = 75.0;
		seedHistoryPercGrid[7][5] = 75.0;
		seedHistoryPercGrid[7][6] = 50.0;
		seedHistoryPercGrid[7][7] = 50.0;
		seedHistoryPercGrid[7][8] = 51.2;
		seedHistoryPercGrid[7][9] = 51.2;
		seedHistoryPercGrid[7][10] = 51.2;
		seedHistoryPercGrid[7][11] = 51.2;
		seedHistoryPercGrid[7][12] = 51.2;
		seedHistoryPercGrid[7][13] = 51.2;
		seedHistoryPercGrid[7][14] = 51.2;
		seedHistoryPercGrid[7][15] = 51.2;
		
		seedHistoryPercGrid[8][0] = 10.0;
		seedHistoryPercGrid[8][1] = 50.0;
		seedHistoryPercGrid[8][2] = 50.0;
		seedHistoryPercGrid[8][3] = 50.0;
		seedHistoryPercGrid[8][4] = 75.0;
		seedHistoryPercGrid[8][5] = 48.8;
		seedHistoryPercGrid[8][6] = 48.8;
		seedHistoryPercGrid[8][7] = 48.8;
		seedHistoryPercGrid[8][8] = 50.0;
		seedHistoryPercGrid[8][9] = 50.0;
		seedHistoryPercGrid[8][10] = 50.0;
		seedHistoryPercGrid[8][11] = 50.0;
		seedHistoryPercGrid[8][12] = 50.0;
		seedHistoryPercGrid[8][13] = 50.0;
		seedHistoryPercGrid[8][14] = 50.0;
		seedHistoryPercGrid[8][15] = 50.0;
		
		seedHistoryPercGrid[9][0] = 14.3;
		seedHistoryPercGrid[9][1] = 36.7;
		seedHistoryPercGrid[9][2] = 30.8;
		seedHistoryPercGrid[9][3] = 30.8;
		seedHistoryPercGrid[9][4] = 30.8;
		seedHistoryPercGrid[9][5] = 40.0;
		seedHistoryPercGrid[9][6] = 39.6;
		seedHistoryPercGrid[9][7] = 39.6;
		seedHistoryPercGrid[9][8] = 39.6;
		seedHistoryPercGrid[9][9] = 50.0;
		seedHistoryPercGrid[9][10] = 50.0;
		seedHistoryPercGrid[9][11] = 50.0;
		seedHistoryPercGrid[9][12] = 50.0;
		seedHistoryPercGrid[9][13] = 50.0;
		seedHistoryPercGrid[9][14] = 50.0;
		seedHistoryPercGrid[9][15] = 50.0;
		
		seedHistoryPercGrid[10][0] = 42.9;
		seedHistoryPercGrid[10][1] = 12.5;
		seedHistoryPercGrid[10][2] = 30.9;
		seedHistoryPercGrid[10][3] = 30.9;
		seedHistoryPercGrid[10][4] = 30.9;
		seedHistoryPercGrid[10][5] = 36.3;
		seedHistoryPercGrid[10][6] = 36.3;
		seedHistoryPercGrid[10][7] = 36.3;
		seedHistoryPercGrid[10][8] = 36.3;
		seedHistoryPercGrid[10][9] = 66.7;
		seedHistoryPercGrid[10][10] = 50.0;
		seedHistoryPercGrid[10][11] = 50.0;
		seedHistoryPercGrid[10][12] = 50.0;
		seedHistoryPercGrid[10][13] = 100.0;
		seedHistoryPercGrid[10][14] = 100.0;
		seedHistoryPercGrid[10][15] = 100.0;
		
		seedHistoryPercGrid[11][0] = 0.0;
		seedHistoryPercGrid[11][1] = 0.0;
		seedHistoryPercGrid[11][2] = 29.3;
		seedHistoryPercGrid[11][3] = 29.3;
		seedHistoryPercGrid[11][4] = 33.1;
		seedHistoryPercGrid[11][5] = 33.1;
		seedHistoryPercGrid[11][6] = 33.1;
		seedHistoryPercGrid[11][7] = 33.1;
		seedHistoryPercGrid[11][8] = 33.1;
		seedHistoryPercGrid[11][9] = 33.1;
		seedHistoryPercGrid[11][10] = 33.1;
		seedHistoryPercGrid[11][11] = 50.0;
		seedHistoryPercGrid[11][12] = 75.0;
		seedHistoryPercGrid[11][13] = 75.0;
		seedHistoryPercGrid[11][14] = 75.0;
		seedHistoryPercGrid[11][15] = 75.0;

		seedHistoryPercGrid[12][0] = 0.0;
		seedHistoryPercGrid[12][1] = 0.0;
		seedHistoryPercGrid[12][2] = 20.1;
		seedHistoryPercGrid[12][3] = 17.6;
		seedHistoryPercGrid[12][4] = 17.6;
		seedHistoryPercGrid[12][5] = 17.6;
		seedHistoryPercGrid[12][6] = 17.6;
		seedHistoryPercGrid[12][7] = 17.6;
		seedHistoryPercGrid[12][8] = 17.6;
		seedHistoryPercGrid[12][9] = 17.6;
		seedHistoryPercGrid[12][10] = 17.6;
		seedHistoryPercGrid[12][11] = 25.0;
		seedHistoryPercGrid[12][12] = 50.0;
		seedHistoryPercGrid[12][13] = 50.0;
		seedHistoryPercGrid[12][14] = 50.0;
		seedHistoryPercGrid[12][15] = 50.0;
		
		seedHistoryPercGrid[13][0] = 0.0;
		seedHistoryPercGrid[13][1] = 0.0;
		seedHistoryPercGrid[13][2] = 15.0;
		seedHistoryPercGrid[13][3] = 15.0;
		seedHistoryPercGrid[13][4] = 12.5;
		seedHistoryPercGrid[13][5] = 12.5;
		seedHistoryPercGrid[13][6] = 12.5;
		seedHistoryPercGrid[13][7] = 12.5;
		seedHistoryPercGrid[13][8] = 12.5;
		seedHistoryPercGrid[13][9] = 12.5;
		seedHistoryPercGrid[13][10] = 12.5;
		seedHistoryPercGrid[13][11] = 12.5;
		seedHistoryPercGrid[13][12] = 12.5;
		seedHistoryPercGrid[13][13] = 50.0;
		seedHistoryPercGrid[13][14] = 50.0;
		seedHistoryPercGrid[13][15] = 50.0;
		
		seedHistoryPercGrid[14][0] = 0.0;
		seedHistoryPercGrid[14][1] = 5.7;
		seedHistoryPercGrid[14][2] = 5.7;
		seedHistoryPercGrid[14][3] = 5.7;
		seedHistoryPercGrid[14][4] = 5.7;
		seedHistoryPercGrid[14][5] = 5.7;
		seedHistoryPercGrid[14][6] = 5.7;
		seedHistoryPercGrid[14][7] = 5.7;
		seedHistoryPercGrid[14][8] = 5.7;
		seedHistoryPercGrid[14][9] = 5.7;
		seedHistoryPercGrid[14][10] = 5.7;
		seedHistoryPercGrid[14][11] = 5.7;
		seedHistoryPercGrid[14][12] = 5.7;
		seedHistoryPercGrid[14][13] = 5.7;
		seedHistoryPercGrid[14][14] = 50.0;
		seedHistoryPercGrid[14][15] = 50.0;
		
		seedHistoryPercGrid[15][0] = 0.7;
		seedHistoryPercGrid[15][1] = 0.7;
		seedHistoryPercGrid[15][2] = 0.7;
		seedHistoryPercGrid[15][3] = 0.7;
		seedHistoryPercGrid[15][4] = 0.7;
		seedHistoryPercGrid[15][5] = 0.7;
		seedHistoryPercGrid[15][6] = 0.7;
		seedHistoryPercGrid[15][7] = 0.7;
		seedHistoryPercGrid[15][8] = 0.7;
		seedHistoryPercGrid[15][9] = 0.7;
		seedHistoryPercGrid[15][10] = 0.7;
		seedHistoryPercGrid[15][11] = 0.7;
		seedHistoryPercGrid[15][12] = 0.7;
		seedHistoryPercGrid[15][13] = 0.7;
		seedHistoryPercGrid[15][14] = 0.7;
		seedHistoryPercGrid[15][15] = 50.0;
		
		double team1HistoricalWinPerc = seedHistoryPercGrid[team1.getSeedNumber()-1][team2.getSeedNumber()-1];
		return team1HistoricalWinPerc;
	}
	
	/**
	 * This method takes two Teams, gets the historical percentage in the seed to seed matchup,
	 * and then uses the math.random function to simulate the matchup based on that percentage and return a winner.
	 * 
	 * @param firstTeam
	 * @param secondTeam
	 * @return winning Team
	 */
    public Team getWinnerHistoricalPerc(Team firstTeam, Team secondTeam) {
        
        double historicalWinPerc = getHistoricalWinPerc(firstTeam, secondTeam);
    	double outcome = Math.random() * 100;
    	Team winner;
    	if (outcome < historicalWinPerc) {
    		winner = firstTeam;
    		}
    	else {
    		winner = secondTeam;
    		}
    	return winner;
    }
	
    
    /**
	 * This method takes two Teams, gets the historical percentage in the seed to seed matchup,
	 * then adjusts the original historical percentage by the difference between each team's field goal percentages,
	 * and, finally, uses the math.random function to simulate the matchup and return a winner.
	 * 
	 * @param firstTeam
	 * @param secondTeam
	 * @return winning Team
	 */
    public Team getWinnerWithFGPercFocus(Team firstTeam, Team secondTeam) {
        
        double historicalWinPercAdjuster = 10 * (firstTeam.getFieldGoalPercentage() - secondTeam.getFieldGoalPercentage());
    	double winPercWithFGPercFocus = getHistoricalWinPerc(firstTeam, secondTeam) + historicalWinPercAdjuster;
    	double outcome = Math.random() * 100;
    	Team winner;
    	if (outcome < winPercWithFGPercFocus) {
    		winner = firstTeam;
    		}
    	else {
    		winner = secondTeam;
    		}
    	return winner;
    }

	/**
	 * This method takes two Teams, gets the historical percentage in the seed to seed matchup,
	 * then adjusts the original historical percentage by the difference between each team's three point percentages,
	 * and, finally, uses the math.random function to simulate the matchup and return a winner.
	 * 
	 * @param firstTeam
	 * @param secondTeam
	 * @return winning Team
	 */
    public Team getWinnerWith3PtShootingFocus(Team firstTeam, Team secondTeam) {
        
        double historicalWinPercAdjuster = 10 * (firstTeam.getThreePointerPercentage() - secondTeam.getThreePointerPercentage());
    	double winPercWith3PtShootingFocus = getHistoricalWinPerc(firstTeam, secondTeam) + historicalWinPercAdjuster;
    	double outcome = Math.random() * 100;
    	Team winner;
    	if (outcome < winPercWith3PtShootingFocus) {
    		winner = firstTeam;
    		}
    	else {
    		winner = secondTeam;
    		}
    	return winner;
    }
    
    /**
     * This method takes two Teams, gets the historical percentage in the seed to seed matchup,
     * then adjusts the original historical percentage by the difference between each team's foul shooting percentages,
     * and, finally, uses the math.random function to simulate the matchup and return a winner.
     * 
     * @param firstTeam
     * @param secondTeam
     * @return winning Team
     */
    public Team getWinnerWithFoulShootingFocus(Team firstTeam, Team secondTeam) {
        
        double historicalWinPercAdjuster = 10 * (firstTeam.getFreeThrowPercentage() - secondTeam.getFreeThrowPercentage());
    	double winPercWithFoulShootingFocus = getHistoricalWinPerc(firstTeam, secondTeam) + historicalWinPercAdjuster;
    	double outcome = Math.random() * 100;
    	Team winner;
    	if (outcome < winPercWithFoulShootingFocus) {
    		winner = firstTeam;
    		}
    	else {
    		winner = secondTeam;
    		}
    	return winner;
    }
    
    /**
     * This method takes two Teams and determines a winner by comparing the sum of each team's 2019 win rating plus 0.2 x math.random;
     * based on our calculations, this method for determining a winner roughly tracks the historical win percentages for each seed, and it offers
     * an additional benefit of being able to account for uniquely good or bad teams notwithstanding the seed they were assigned.
     * 
     * @param firstTeam
     * @param secondTeam
     * @return winning Team
     */
    public Team getWinnerByWinRating(Team firstTeam, Team secondTeam) {
            	
    	double winPercentFirst = firstTeam.getWinRating();
        double winPercentSecond = secondTeam.getWinRating();
        double firstTeamChances = winPercentFirst + (Math.random() * 0.2);
        double secondTeamChances = winPercentSecond + (Math.random() * 0.2);
        if(firstTeamChances >= secondTeamChances) {
           return firstTeam;
        }
        else {
        	return secondTeam;
        	}
    }		
}
    
    
    

