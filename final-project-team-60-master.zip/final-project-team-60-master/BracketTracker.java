
public class BracketTracker {
	
	Team[][] bracket = new Team[32][13];
	
	
	public String getTeamAtBracketPosition(int x, int y) {
		String testTeamName = bracket[x][y].getSchoolName();
		return testTeamName;
	}

	//create 2D array to track teams along bracket; begin by filling in teams by seed and region
	public void initializeBracketTracker() {
		
		//1 seeds
		bracket[0][0] = TeamDataReader.getTeams().get(0);
	    bracket[0][12] = TeamDataReader.getTeams().get(1);
	    bracket[16][0] = TeamDataReader.getTeams().get(2);
	    bracket[16][12] = TeamDataReader.getTeams().get(3);
	    
	    //16 seeds
	    bracket[1][0] = TeamDataReader.getTeams().get(60);
	    bracket[1][12] = TeamDataReader.getTeams().get(61);
	    bracket[17][0] = TeamDataReader.getTeams().get(62);
	    bracket[17][12] = TeamDataReader.getTeams().get(63);
	    
	    //8 seeds
	    bracket[2][0] = TeamDataReader.getTeams().get(28);
	    bracket[2][12] = TeamDataReader.getTeams().get(29);
	    bracket[18][0] = TeamDataReader.getTeams().get(30);
	    bracket[18][12] = TeamDataReader.getTeams().get(31);
	    
	    //9 seeds
	    bracket[3][0] = TeamDataReader.getTeams().get(32);
	    bracket[3][12] = TeamDataReader.getTeams().get(33);
	    bracket[19][0] = TeamDataReader.getTeams().get(34);
	    bracket[19][12] = TeamDataReader.getTeams().get(35);
	    
	    //5 seeds
	    bracket[4][0] = TeamDataReader.getTeams().get(16);
	    bracket[4][12] = TeamDataReader.getTeams().get(17);
	    bracket[20][0] = TeamDataReader.getTeams().get(18);
	    bracket[20][12] = TeamDataReader.getTeams().get(19);
	    
	    //12 seeds
	    bracket[5][0] = TeamDataReader.getTeams().get(44);
	    bracket[5][12] = TeamDataReader.getTeams().get(45);
	    bracket[21][0] = TeamDataReader.getTeams().get(46);
	    bracket[21][12] = TeamDataReader.getTeams().get(47);
	    
	    //4 seeds
	    bracket[6][0] = TeamDataReader.getTeams().get(12);
	    bracket[6][12] = TeamDataReader.getTeams().get(13);
	    bracket[22][0] = TeamDataReader.getTeams().get(14);
	    bracket[22][12] = TeamDataReader.getTeams().get(15);
	    
	    //13 seeds
	    bracket[7][0] = TeamDataReader.getTeams().get(48);
	    bracket[7][12] = TeamDataReader.getTeams().get(49);
	    bracket[23][0] = TeamDataReader.getTeams().get(50);
	    bracket[23][12] = TeamDataReader.getTeams().get(51);
	    
	    //6 seeds
	    bracket[8][0] = TeamDataReader.getTeams().get(20);
	    bracket[8][12] = TeamDataReader.getTeams().get(21);
	    bracket[24][0] = TeamDataReader.getTeams().get(22);
	    bracket[24][12] = TeamDataReader.getTeams().get(23);
	    
	    //11 seeds
	    bracket[9][0] = TeamDataReader.getTeams().get(40);
	    bracket[9][12] = TeamDataReader.getTeams().get(41);
	    bracket[25][0] = TeamDataReader.getTeams().get(42);
	    bracket[25][12] = TeamDataReader.getTeams().get(43);
	    
	    //3 seeds
	    bracket[10][0] = TeamDataReader.getTeams().get(8);
	    bracket[10][12] = TeamDataReader.getTeams().get(9);
	    bracket[26][0] = TeamDataReader.getTeams().get(10);
	    bracket[26][12] = TeamDataReader.getTeams().get(11);
	    
	    //14 seeds
	    bracket[11][0] = TeamDataReader.getTeams().get(52);
	    bracket[11][12] = TeamDataReader.getTeams().get(53);
	    bracket[27][0] = TeamDataReader.getTeams().get(54);
	    bracket[27][12] = TeamDataReader.getTeams().get(55);
	    
	    //7 seeds
	    bracket[12][0] = TeamDataReader.getTeams().get(24);
	    bracket[12][12] = TeamDataReader.getTeams().get(25);
	    bracket[28][0] = TeamDataReader.getTeams().get(26);
	    bracket[28][12] = TeamDataReader.getTeams().get(27);
	    
	    //10 seeds
	    bracket[13][0] = TeamDataReader.getTeams().get(36);
	    bracket[13][12] = TeamDataReader.getTeams().get(37);
	    bracket[29][0] = TeamDataReader.getTeams().get(38);
	    bracket[29][12] = TeamDataReader.getTeams().get(39);
	    
	    //2 seeds
	    bracket[14][0] = TeamDataReader.getTeams().get(4);
	    bracket[14][12] = TeamDataReader.getTeams().get(5);
	    bracket[30][0] = TeamDataReader.getTeams().get(6);
	    bracket[30][12] = TeamDataReader.getTeams().get(7);
	    
	    //15 seeds
	    bracket[15][0] = TeamDataReader.getTeams().get(56);
	    bracket[15][12] = TeamDataReader.getTeams().get(57);
	    bracket[31][0] = TeamDataReader.getTeams().get(58);
	    bracket[31][12] = TeamDataReader.getTeams().get(59);
		
	}
	
}
