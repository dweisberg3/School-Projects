import java.util.*;
import java.io.*;

/**
 * TeamDataReader reads the CSV file containing team data
 * @author Jordan Mabalatan
 *
 */

public class TeamDataReader {
	
	private static ArrayList<Team> teams;
    
	public static ArrayList<Team> getTeams() {
		return teams;
	}
	
    public static void readCSV() {
       teams = new ArrayList<Team>();
       File teamsFile = new File("topSixtyFourTeams with winRating.csv");
       try {
            Scanner fileReader = new Scanner(teamsFile);
            fileReader.nextLine();
            while(fileReader.hasNextLine()) {
                String teamRow = fileReader.nextLine();
                String [] columnData = teamRow.split(",");
                                   
                String schoolName = columnData[0];
                String shortName = columnData[1]; 
                String region = columnData[2];
                int seedNumber = Integer.parseInt(columnData[3]);
                double winRating = Double.parseDouble(columnData[4]);
                double gamesPlayed = Double.parseDouble(columnData[5]);
                double gamesWon = Double.parseDouble(columnData[6]);
                double gamesLost = Double.parseDouble(columnData[7]);
                double winLossPercentage = Double.parseDouble(columnData[8]);
                double strengthOfSchedule = Double.parseDouble(columnData[9]);
                double minutesPlayed = Double.parseDouble(columnData[10]);
                double fieldGoalsMade = Double.parseDouble(columnData[11]);
                double fieldGoalsAttempted = Double.parseDouble(columnData[12]);
                double fieldGoalPercentage = Double.parseDouble(columnData[13]);
                double threePointersMade = Double.parseDouble(columnData[14]);
                double threePointersAttempted = Double.parseDouble(columnData[15]);
                double threePointerPercentage = Double.parseDouble(columnData[16]);
                double freeThrowsMade = Double.parseDouble(columnData[17]);
                double freeThrowsAttempted = Double.parseDouble(columnData[18]);
                double freeThrowPercentage = Double.parseDouble(columnData[19]);
                double offensiveRebounds = Double.parseDouble(columnData[20]);
                double defensiveRebounds = Double.parseDouble(columnData[21]);
                double totalRebounds = Double.parseDouble(columnData[22]);
                double assists = Double.parseDouble(columnData[23]);
                double steals = Double.parseDouble(columnData[24]);
                double blocks = Double.parseDouble(columnData[25]);
                double turnovers = Double.parseDouble(columnData[26]);
                double personalFouls = Double.parseDouble(columnData[27]);
                
                Team team = new Team(schoolName, shortName, region, seedNumber, winRating, gamesPlayed, gamesWon, gamesLost, winLossPercentage, strengthOfSchedule, minutesPlayed, 
                        fieldGoalsMade, fieldGoalsAttempted, fieldGoalPercentage, threePointersMade, threePointersAttempted, threePointerPercentage, 
                        freeThrowsMade, freeThrowsAttempted, freeThrowPercentage, offensiveRebounds, defensiveRebounds, totalRebounds, assists, steals, blocks, turnovers, personalFouls);
                
                teams.add(team);
               
            }
            fileReader.close();
        } 
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
       	
    }
    
}