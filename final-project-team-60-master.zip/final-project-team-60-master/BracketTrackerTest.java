import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BracketTrackerTest {

	@Test
	void testInitializeBracketTrackerKansas() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(0, 0), "Kansas");
	}
	
	@Test
	void testInitializeBracketTrackerDuke() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(16, 0), "Duke");
	}
	
	@Test
	void testInitializeBracketTrackerGonzaga() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(0, 12), "Gonzaga");
	}
	
	@Test
	void testInitializeBracketTrackerTexas() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(1, 12), "Texas");
	}
	
	@Test
	void testInitializeBracketTrackerVirginia() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(7, 0), "Virginia");
	}
	
	@Test
	void testInitializeBracketTrackerBaylor() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(14, 0), "Baylor");
	}
	
	@Test
	void testInitializeBracketTrackerOhioState() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(30, 0), "Ohio State");
	}
	
	@Test
	void testInitializeBracketTrackerDayton() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(30, 12), "Dayton");
	}
	
	@Test
	void testInitializeBracketTrackerRutgers() {
		BracketTracker bt1 = new BracketTracker();
		TeamDataReader.readCSV();
		bt1.initializeBracketTracker();
		assertEquals(bt1.getTeamAtBracketPosition(28, 12), "Rutgers");
	}
	

}
